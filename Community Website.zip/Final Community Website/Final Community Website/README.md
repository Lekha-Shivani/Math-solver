# GaFAQ
This is a website that is similar to quora . This a student project done for learning.
https://stormy-inlet-30309.herokuapp.com/ - hosted
